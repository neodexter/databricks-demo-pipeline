# Databricks notebook source
# MAGIC %md
# MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Catalogs and Pipelines
# MAGIC
# MAGIC #### Steps
# MAGIC 1. Explore Workspace 
# MAGIC 2. Create Catalog and Schema 
# MAGIC 3. Run Data Generator
# MAGIC 4. Create Cost Control View
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Explore the workspace
# MAGIC We are going explore the workspace, specifically we need to pay attention to:
# MAGIC 1. Catalog Explorer Tab
# MAGIC     1. What catalogs can we see?
# MAGIC     2. What Shared Catalogs?
# MAGIC 2. Notebook and Compute tabs
# MAGIC     1. What tabs do we need? 
# MAGIC     2. What are the default languages we might use? 
# MAGIC     3. What is markdown (this text)?
# MAGIC     4. What compute are we using?
# MAGIC     5. How to create tags for the Compute?
# MAGIC 3.  Jobs & Pipelines tab
# MAGIC     1. What is the pipeline creation going to look like? 
# MAGIC     2. What types of pipelines can we create?
# MAGIC 4. Dashboards
# MAGIC 5. Genie Spaces
# MAGIC 6. Serving 
# MAGIC     1. What kind of models are we seeing here?
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Catalogs
# MAGIC
# MAGIC For our Ingestion workload we want to create a catalog called `field_lab_(username)` where `(username)` is our username  and we want create a schema called `pipeline` and we want to have access to a Volume called `raw_loan_data`, we also want to set up default catalogs and schemas, that might make our lives a little bit easier 
# MAGIC
# MAGIC ##### Hints: 
# MAGIC * ` CREATE ___ IF NOT EXISTS ` makes our code re-runnable
# MAGIC * `USE CATALOG` makes our lives easier
# MAGIC *  putting backticks ` in the name of the schema can enable us to use any type of name we want
# MAGIC * checking the volume access can be done in SQL or the Catalog Explorer

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS `my_catalog_name`;
# MAGIC CREATE SCHEMA IF NOT EXISTS `my_catalog_name`.pipeline;

# COMMAND ----------

# MAGIC %sql
# MAGIC --only for instructors or when doing the lab alone
# MAGIC CREATE SCHEMA IF NOT EXISTS fieldlab.raw_loan_data;
# MAGIC CREATE VOLUME IF NOT EXISTS fieldlab.raw_loan_data.src;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Run loan data generator
# MAGIC We are going to run our data generator, or we are going to get access to the data we can find in this Volume that it creates. The exact nature and code of the generator is not part of the course, this is a synthetic dataset that contains transaction data being randomly generated
# MAGIC

# COMMAND ----------

# only for instructors or when doing the lab alone
dbutils.notebook.run("./Setup/Loan-Data-Generator", timeout_seconds=0, arguments={
    'path': "/Volumes/fieldlab/raw_loan_data/src",
    'reset_all_data': 'true',
    'batch_wait': '60',
    'num_recs': '100',
    'batch_count': '500'
})