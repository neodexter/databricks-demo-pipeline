-- Databricks notebook source
-- MAGIC %md
-- MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Ingest into Bronze layer
-- MAGIC
-- MAGIC The first step in our pipeline is to create our bronze layer which will take our raw data and ingest it into Delta tables.
-- MAGIC
-- MAGIC Our goal here is going be to get our Volume and the data inside it and turn it into a set of tables in our Lakeflow Declarative Pipeline.
-- MAGIC
-- MAGIC The thought process should always follow this schema:
-- MAGIC
-- MAGIC * Look at the original data in the Volume
-- MAGIC * Write code
-- MAGIC * Validate the new code
-- MAGIC * Run with data being ingested
-- MAGIC * Repeat :)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Raw Transactions
-- MAGIC We are going to start with a streaming table called `raw_txs` which will ingest our `raw_transactions` which are json files into a STREAMING TABLE
-- MAGIC
-- MAGIC It's also important to add comments to all of our tables so later on we know what did we create
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `CREATE OR REFRESH STREAMING TABLE`
-- MAGIC * `cloud_files()` with `json` argument 
-- MAGIC * name should be `raw_txs`
-- MAGIC * `map("cloudFiles.inferColumnTypes", "true")`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lookup Table
-- MAGIC Our second table is going to be a `MATERIALIZED VIEW` for our accounting treatment which is a `DELTA` table already
-- MAGIC
-- MAGIC Hints:
-- MAGIC *  `CREATE OR REFRESH MATERIALIZED VIEW` 
-- MAGIC * `SELECT __ FROM delta.`
-- MAGIC * name should be `ref_accounting_treatment`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lab
-- MAGIC The last table in our bronze layer is going to be for historical loan data which are stored in csv files
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `CREATE OR REFRESH STREAMING TABLE`
-- MAGIC * `cloud_files()` with CSV parameter
-- MAGIC * name should be `raw_historical_loans`
-- MAGIC * `map("cloudFiles.inferColumnTypes", "true")`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Resources
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/sql/language-manual/" target="_blank">SQL Reference</a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/ingestion/cloud-object-storage/auto-loader/options" target="_blank">Autoloader reference</a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/dlt/configure-pipeline" target="_blank">Lakeflow Declarative Pipelines settings reference</a>
-- MAGIC