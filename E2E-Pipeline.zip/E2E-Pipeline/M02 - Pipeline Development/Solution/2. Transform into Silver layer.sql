-- Databricks notebook source
-- MAGIC %md
-- MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Transform in the Silver Layer
-- MAGIC
-- MAGIC Now we are going to move to our transformation layer. We are also going to use our first `CONSTRAINTS` and our first `VIEW` to help us with complex joins. 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## New Transactions Join View
-- MAGIC
-- MAGIC First we are going to create a `TEMPORARY VIEW` that will join `raw_txs` and `ref_accounting_treatment` with an `INNER JOIN` on their ids. The view will enable us to manage our code a bit better, here creating the join and then using the view as a source for a new streaming table with constraints
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `INNER JOIN`
-- MAGIC * `STREAM()`
-- MAGIC * `CREATE TEMPORARY VIEW`
-- MAGIC * `COMMENT`
-- MAGIC * name should be `new_txs`

-- COMMAND ----------

CREATE TEMPORARY VIEW new_txs
COMMENT "Livestream of new transactions" AS
SELECT
  txs.*,
  ref.accounting_treatment as accounting_treatment
FROM
  stream (raw_txs) txs
    INNER JOIN ref_accounting_treatment ref
      ON txs.accounting_treatment_id = ref.id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Silver Transaction Streaming Table
-- MAGIC
-- MAGIC We are going to create a new streaming table that will have the following constraints:
-- MAGIC * Payments should be this year
-- MAGIC * Balance should be positive otherwise drop the row
-- MAGIC * Cost center must be specified otherwise fail the update
-- MAGIC
-- MAGIC It will load the data from the live view we created just above
-- MAGIC
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `CONSTRAINT description EXPECT condition`
-- MAGIC * ` CREATE OR REFRESH STREAMING TABLE`
-- MAGIC * Name should be `cleaned_new_txs`
-- MAGIC * `STREAM()` keyword

-- COMMAND ----------

CREATE OR REFRESH STREAMING TABLE cleaned_new_txs
  (
    CONSTRAINT `Payments should be this year` EXPECT(next_payment_date > date('2024-12-31')),
    CONSTRAINT `Balance should be positive` EXPECT(
      balance > 0
      AND arrears_balance > 0
    ) ON VIOLATION DROP ROW,
    CONSTRAINT `Cost center must be specified` EXPECT(
      cost_center_code IS NOT NULL
    ) ON VIOLATION FAIL UPDATE
  )
  COMMENT "Livestream of new transactions, cleaned and compliant" AS
SELECT
  *
FROM
  STREAM(new_txs);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lab #1
-- MAGIC Now we are going to manually create inverse rules to create a quarantine table (this will be automated at one point).
-- MAGIC The quarantine table will contain those rows, where the balance is negative, or the dates are older than the current year.
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `CONSTRAINT description EXPECT condition`
-- MAGIC * Name should be `quarantine_bad_txs`

-- COMMAND ----------

CREATE OR REFRESH STREAMING TABLE quarantine_bad_txs
  (
    CONSTRAINT `Payments should be this year` EXPECT(next_payment_date <= date('2024-12-31')),
    CONSTRAINT `Balance should be positive` EXPECT(
      balance <= 0
      OR arrears_balance <= 0
    ) ON VIOLATION DROP ROW
  )
  COMMENT "Incorrect transactions requiring human analysis" AS
SELECT
  *
from
  STREAM(new_txs);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lab #2
-- MAGIC Finally we are going to handle the last bit of data we haven't touched, which is the `raw_historical_loans` table. We are going to store that in a materialized view with a join to `accounting_treatment`, just like our live view. 
-- MAGIC
-- MAGIC Hints:
-- MAGIC * `CREATE OR REFRESH MATERIALIZED VIEW`
-- MAGIC * use `INNER JOIN` with `raw_historical_loans` and `ref_accounting_treatment`
-- MAGIC * Name should be `historical_txs`
-- MAGIC

-- COMMAND ----------

CREATE OR REFRESH MATERIALIZED VIEW historical_txs
  COMMENT "Historical loan transactions" AS
SELECT
  l.*,
  ref.accounting_treatment as accounting_treatment
FROM
  raw_historical_loans l
    INNER JOIN ref_accounting_treatment ref
      ON l.accounting_treatment_id = ref.id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Resources
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/dlt/expectations?language=SQL" target="_blank">Constraints </a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/dlt/streaming-tables" target="_blank">Streaming concepts </a>
-- MAGIC