-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## Exploring the load data
-- MAGIC
-- MAGIC Let's have a look to the files that we have as source for our pipeline.

-- COMMAND ----------

LIST '/Volumes/fieldlab/raw_loan_data/src'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Look a the files in the `/historical_loans/` subfolder using the Catalog explorer.
-- MAGIC
-- MAGIC 👉 Go to the *Catalog* tab

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Look at the csv file programmatically

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.head('/Volumes/fieldlab/raw_loan_data/src/historical_loans/part-00000-tid-<a_very_long_text_with_random_characters>.csv'))

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Let's reivew the `/raw_transactions` folder

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.ls('/Volumes/fieldlab/raw_loan_data/src/raw_transactions'))

-- COMMAND ----------

-- MAGIC %md
-- MAGIC We can read in `json` formatted files direcly

-- COMMAND ----------

SELECT * FROM json.`/Volumes/fieldlab/raw_loan_data/src/raw_transactions/part-00000-tid-<a_very_long_text_with_random_characters>.json`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Read an entire folder of data

-- COMMAND ----------

SELECT count(*) FROM json.`/Volumes/fieldlab/raw_loan_data/src/raw_transactions/`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC There is PySpark syntax for the python folks.

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.read.format("json").load("/Volumes/fieldlab/raw_loan_data/src/raw_transactions/part-00000-tid-<a_very_long_text_with_random_characters>.json").display()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Finally let's look into the `/ref_accounting_treatment` folder

-- COMMAND ----------

LIST '/Volumes/fieldlab/raw_loan_data/src/ref_accounting_treatment/'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.read.load('/Volumes/fieldlab/raw_loan_data/src/ref_accounting_treatment/').display()