# Databricks notebook source
# MAGIC %md
# MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Create pipeline
# MAGIC
# MAGIC ## Set Up Pipeline
# MAGIC
# MAGIC We are going to set up a pipeline which is going to be empty at the moment, and then, we are going to write the code to process our data.
# MAGIC
# MAGIC | Setting                     | Choice                     |
# MAGIC |-----------------------------|----------------------------|
# MAGIC | Name                        | *Your bank name* Loan Analysis                 |
# MAGIC | Compute                     | Serverless                 |
# MAGIC | Target Schema and catalog   | **`<your_catalog>.pipeline`**  |
# MAGIC | Root fodler                 | **`Loan Pipeline`** |
# MAGIC | Source code                 | **`transformations/01 Ingest into Bronze Layer.sql`**</br>`transformations/02 Transform into Silver Layer.sql`</br>`transformations/03 Aggregate in Gold Layer.sql`        |
# MAGIC | Usage policy                | **`fieldlab`**       |
# MAGIC | Event log table path        | **`<your_catalog>.pipeline.logs`**  |
# MAGIC
# MAGIC Note: We'll add source code files as we progress, we only need to add one at a time.
# MAGIC