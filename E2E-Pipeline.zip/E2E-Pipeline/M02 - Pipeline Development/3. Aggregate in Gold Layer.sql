-- Databricks notebook source
-- MAGIC %md
-- MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Aggregate in the Gold Layer
-- MAGIC
-- MAGIC Our last layer is going to be the Gold Layer, where we aggregate our data and create materialized views that we will further explore in our Dashboard

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Balances by Cost Center
-- MAGIC For our first table, we are going to create a sum of all balances based on the `cleaned_new_txs` table and we are going to group that by cost centers
-- MAGIC
-- MAGIC Hint:
-- MAGIC * Use `GROUP BY`
-- MAGIC * `CREATE OR REFRESH MATERIALIZED VIEW`
-- MAGIC * Use `cleaned_new_txs`
-- MAGIC * Name should be `new_loan_balances_by_cost_center`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Total loan balances with Liquid Clustering
-- MAGIC Next, we are going to create a total view of the state level loan sums by `UNION`-ing together the two silver tables that we have used so far, and also add a Z-ordering to our table. First, do a `GROUP BY` on them by state!
-- MAGIC
-- MAGIC Hints:
-- MAGIC * Use `TBLPROPERTIES` to add Z-order
-- MAGIC * use `UNION` from `historical_txs` and `cleaned_new_txs`
-- MAGIC * name it `total_loan_balances`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lab
-- MAGIC Finally we are going to create a sum of loans by country code 
-- MAGIC
-- MAGIC Hint:
-- MAGIC * Use `GROUP BY`
-- MAGIC * `CREATE OR REFRESH MATERIALIZED VIEW`
-- MAGIC * Use `cleaned_new_txs`
-- MAGIC * Name should be `new_loan_balances_by_country`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Resources
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/delta/clustering" target="_blank">Liquid Clustering </a>
-- MAGIC