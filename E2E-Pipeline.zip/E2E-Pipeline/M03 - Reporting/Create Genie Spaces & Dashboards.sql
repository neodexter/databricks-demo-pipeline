-- Databricks notebook source
-- MAGIC %md
-- MAGIC <img src="https://paocontentstorage.blob.core.windows.net/geospatial/field_lab_logo_edu.png" width="400">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Create Genies Spaces & Dashboards
-- MAGIC
-- MAGIC ## What does our dashboard need?
-- MAGIC 1. Data from gold (and silver) tables in the dataset
-- MAGIC 2. Visualizations
-- MAGIC
-- MAGIC ### Datasets:
-- MAGIC 1. All gold tables as they are
-- MAGIC     1. What questions do we want to answer?
-- MAGIC 2. Silver table aggregations in the Dashboard
-- MAGIC     1. What tables do we need?
-- MAGIC     2. What questions do we want to answer?
-- MAGIC 3. Events logs in the dashboard
-- MAGIC     1. Metrics on pipeline in the same dashboard
-- MAGIC
-- MAGIC ### Visualizations:
-- MAGIC 1. What colors do we want to use
-- MAGIC 2. What metrics do we want to visualize, what metrics should go into the datasets?

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ## Pipeline events
-- MAGIC
-- MAGIC We can get information about the pipeline status programmatically using the published events table.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Lab
-- MAGIC Create a new visualization
-- MAGIC * Look at the data, our tables, and event logs
-- MAGIC * Search for any meaningful qualitative measure
-- MAGIC * Include it the dashboard

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Create a Genie space with the dashboard
-- MAGIC
-- MAGIC To set up a Genie space we can create an *attached Genie space to the dashboard* that we already have so that our datasets show up
-- MAGIC
-- MAGIC When setting up Genie Spaces consider the following:
-- MAGIC * Who is using our spaces and with what rights? 
-- MAGIC * What common questions might we ask? 
-- MAGIC * What functions can we bring in for the space to execute? 
-- MAGIC * What should our system prompt be?
-- MAGIC
-- MAGIC ##### Lab
-- MAGIC Find good questions for Genie to ask:
-- MAGIC
-- MAGIC Make sure to consider this using the data, try a few options out, this is an open ended lab

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Use AI functions to enhance data
-- MAGIC
-- MAGIC One clear question we have is that our data lacks proper names for the countries, but luckily we can extend that with AI.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Resources
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/sql/language-manual/functions/ai_query#foundation-model" target="_blank">ai_query reference</a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/large-language-models/ai-functions" target="_blank">AI functions reference</a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/gcp/en/ai-bi/" target="_blank">Dashboard docs</a>
-- MAGIC
-- MAGIC <a href="https://docs.databricks.com/aws/en/genie/" target="_blank">Genie Docs</a>
-- MAGIC