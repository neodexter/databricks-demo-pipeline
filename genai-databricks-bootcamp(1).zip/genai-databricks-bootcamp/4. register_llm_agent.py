# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC ### Lab 4: Register your model
# MAGIC
# MAGIC Recap: You'll register your model with Unity catalog, enabling it for other users and for chatting with it in the playground!
# MAGIC
# MAGIC #### What you'll learn in this notebook:
# MAGIC - How to log your agent with mlflow
# MAGIC - How to deploy your agent
# MAGIC
# MAGIC **Output of this lab:**
# MAGIC - Logged meta data of your agents
# MAGIC - A chat-ready agent
# MAGIC  
# MAGIC ---
# MAGIC
# MAGIC ✅ Let's deploy your agent!

# COMMAND ----------

# MAGIC %pip install mlflow databricks-agents backoff mlflow databricks_openai pydantic uv

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

%run ./agent_3.py

# COMMAND ----------

# DBTITLE 1,Imports
import sys
sys.path.append('./')

import mlflow
from mlflow.models.resources import DatabricksFunction, DatabricksServingEndpoint
from databricks import agents

from agent_3 import AGENT, LLM_ENDPOINT_NAME, VECTOR_SEARCH_TOOLS

# COMMAND ----------

# MAGIC %md
# MAGIC ## Task 1: Set up parameters with widgets
# MAGIC We need widgets again! Setup the parameters for the agent registration.
# MAGIC
# MAGIC In here we also reference our agent catalog. An agent catalog in Databricks is essentially a centralized registry or repository of pre-built “agents”. Think of it as a library where different agents, each with their own capabilities and configuration details, are organized and made discoverable so that users or pipelines can easily select and call upon the right agent for a given task. This could be used in case we end out we several agent in an LLMOps setup or in case of a lab like ours. Here we will just go with our models-catalog!
# MAGIC
# MAGIC Instructions:
# MAGIC
# MAGIC 1. Find our index we created earlier.
# MAGIC 2. Define a name for our endpoint. This is what we will call when we want to chat with the agent.
# MAGIC 3. Give the agent a name. 
# MAGIC 4. Set the name of the agent catalog. This is predefined for you.
# MAGIC 5. Finally, ID your project.

# COMMAND ----------

# First, you need to define a username. This will be added to the name of your output table so you can easily see which one is yours.
# TODO: Replace "Your-Username-Here" with your own:
username = "bna"

# Here we are manually creating widgets for our parameters.
dbutils.widgets.text("index_name", f"bootcamp_vectorstores_dev.royal_knowledgebase.bootcamp_index_{username}")
dbutils.widgets.text("model_endpoint_name", f"agent_{username}_endpoint") 
dbutils.widgets.text("agent_name", f"agent_{username}")
dbutils.widgets.text("agent_catalog", f"bootcamp_models_dev.agent_catalog")
dbutils.widgets.text("project_id", f"project_{username}")

# COMMAND ----------

# DBTITLE 1,Define input and output variables
index_name = dbutils.widgets.get("index_name")
model_endpoint_name = dbutils.widgets.get("model_endpoint_name")
agent_name = dbutils.widgets.get("agent_name")
agent_catalog = dbutils.widgets.get("agent_catalog")
project_id = dbutils.widgets.get("project_id")

# COMMAND ----------

# MAGIC %md
# MAGIC You can test out the agent, defined from our python script. Give it a go!

# COMMAND ----------

# DBTITLE 1,Test agent with query
for chunk in AGENT.predict_stream(
    {"messages": [{"role": "user", "content": "How many times USA was mentioned in the royal speech"}]}
):
    print(chunk, "-----------\n")

# COMMAND ----------

# MAGIC %md
# MAGIC This code snippet is setting up a list of Databricks resources and then logging an MLflow model while associating those resources with it. The overall goal is to facilitate automatic authentication passthrough at deployment time, so that when the model (in this case, an "agent") is deployed, it automatically has access to the necessary Databricks services without extra manual configuration.

# COMMAND ----------

# DBTITLE 1,Log agent with MLFlow
# Determine Databricks resources to specify for automatic auth passthrough at deployment time
resources = [DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT_NAME)]
for tool in VECTOR_SEARCH_TOOLS:
    resources.extend(tool.resources)

with mlflow.start_run():
    logged_agent_info = mlflow.pyfunc.log_model(
        artifact_path="agent",
        python_model="agent_3.py",
        pip_requirements=[
            "mlflow",
            "backoff",
            "databricks-openai",
        ],
        resources=resources,
        
    )

# COMMAND ----------

# DBTITLE 1,Validate MLFlow logged agent
mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data={"messages": [{"role": "user", "content": "Hello!"}]},
    env_manager="local",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Task 2: Register and deploy the agent.
# MAGIC Now we need to add the agent to the Unity Catalog based registry. Give it the string of the agent catalog and the agent name.

# COMMAND ----------

# DBTITLE 1,Register agent i UC
mlflow.set_registry_uri("databricks-uc")

# Enter you model reference here
UC_MODEL_NAME = f"bootcamp_models_dev.agent_catalog.agent_bna"

# Register the model to UC
uc_registered_model_info = mlflow.register_model(model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME)

# COMMAND ----------

agents.deploy(
    UC_MODEL_NAME, uc_registered_model_info.version, tags={"projectId": project_id}
)

# COMMAND ----------

# MAGIC %md
# MAGIC Congratulations! You can now access your agent from the served models. Try adding it to the playground and start chatting with it!