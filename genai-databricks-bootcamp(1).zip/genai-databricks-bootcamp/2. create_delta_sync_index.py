# Databricks notebook source
# MAGIC %md
# MAGIC ### Lab 2: Creating a Delta Sync Index for Vector Search
# MAGIC
# MAGIC Recap: You'll create a Retrieval-Augmented Generation (RAG) powered chatbot with a royal flair — a digital chat version of Queen Margrethe II 👑
# MAGIC
# MAGIC > This notebook sets up your data for smart search → Creating a meaningful search index that stays up to date automatically
# MAGIC
# MAGIC #### What you'll learn in this notebook:
# MAGIC - How to create and configure a Vector Search endpoint
# MAGIC - How to create a Delta Sync Index that automatically updates as your source data changes
# MAGIC - How to query and test your vector search index
# MAGIC
# MAGIC
# MAGIC **Output of this lab:**
# MAGIC - Your data prepared and ready for smart search → Embedded data and a functioning Vector Search endpoint
# MAGIC - A search setup (Delta Sync Index) that keeps itself up to date when your data changes
# MAGIC - The ability to perform semantic search on your processed documents, i.e. ability to search your documents based on meaning
# MAGIC  
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ✅ Let's get started building our vector search capabilities!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Load libraries
# MAGIC

# COMMAND ----------

%pip install databricks-vectorsearch
%pip install databricks-feature-engineering
dbutils.library.restartPython()

# COMMAND ----------

from databricks.feature_engineering import FeatureEngineeringClient

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2: Create widgets
# MAGIC First, we will create widgets to store configuration parameters for our vector search index. The widget parameters has been predefined for you in this task. You only need to add the same username as in Notebook 1 in the cell below and run it. 
# MAGIC
# MAGIC All widgets has been predefined for you. We will all use **the same vector search endpoint**, so it is iportant that you **do not** change the name of this.
# MAGIC

# COMMAND ----------

# First, you need to define a username. This will be added to the name of your output table so you can easily see which one is yours.
# Second, give your vector search endpoint a name so you can reference it later.
# TODO: Replace "Your-Username-Here" with your own:
username = "bna"

# Manually creating  widgets
dbutils.widgets.text("source_table", f"bootcamp_vectorstores_dev.royal_knowledgebase.newyears_speeches_chunked_{username}")
dbutils.widgets.text("endpoint_name", "")
dbutils.widgets.text("index_name", f"bootcamp_vectorstores_dev.royal_knowledgebase.bootcamp_index_{username}")
dbutils.widgets.text("primary_key", "chunk_id")
dbutils.widgets.text("embedding_source_column", "chunk")

# COMMAND ----------

# Retrieve widget values for user input
source_table = dbutils.widgets.get("source_table")
endpoint_name = dbutils.widgets.get("endpoint_name")
index_name = dbutils.widgets.get("index_name")
primary_key = dbutils.widgets.get("primary_key")
embedding_source_column = dbutils.widgets.get("embedding_source_column")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Vector Search
# MAGIC
# MAGIC Vector Search in Databricks consists of two key components:
# MAGIC 1. **Vector Search Endpoint**: 
# MAGIC     - This is the infrastructure that hosts and serves your vector indexes. Think of it as entry point to handle your search request.
# MAGIC 2. **Vector Search Index**: 
# MAGIC     - The data structure containing your vector embeddings
# MAGIC
# MAGIC
# MAGIC A Vector Search endpoint has already been created as we will all share one endpoint. You can view it in the Vector Search Endpoints UI.
# MAGIC
# MAGIC Read more documentation about vector search here: https://api-docs.databricks.com/python/vector-search/databricks.vector_search.html
# MAGIC
# MAGIC Run cell below without any modifications.

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient
# The following line automatically generates a PAT Token for authentication
client = VectorSearchClient()
try:
    client.create_endpoint_and_wait(
        name=endpoint_name,
        endpoint_type="STANDARD"
    )
except Exception as e:
    print("Endpoint already exists")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Create a Vector Search Index
# MAGIC
# MAGIC Now that we have our endpoint set up, we can create a vector search index. We will setup a _Delta Sync Index_, which will maintain a vector representation of your data and automatically update as your source data changes.
# MAGIC
# MAGIC However, before creating the search index in Databricks, one must first decide how to provide vector embeddings. Databricks supports different options but in this lab we use the following:
# MAGIC
# MAGIC - **Managed embeddings:** Embeddings computed by Databricks. You provide a text column and endpoint name and Databricks synchronizes the index with your Delta table **(what we'll use in this lab)**
# MAGIC
# MAGIC
# MAGIC Read more details about the different options for providing vector embeddings here: https://docs.databricks.com/aws/en/generative-ai/vector-search 
# MAGIC
# MAGIC --- 
# MAGIC
# MAGIC #### Instructions:
# MAGIC - Create Delta Sync Index using Python SDK in below cell
# MAGIC
# MAGIC 💡 Tip: See documentation here: https://docs.databricks.com/aws/en/generative-ai/create-query-vector-search#create-index-using-the-python-sdk or here: https://api-docs.databricks.com/python/vector-search/databricks.vector_search.html 

# COMMAND ----------

# TODO: Add parameters to the following function call to create delta sync index 
# Create the Delta Sync Index (takes approx. 4 minutes. to run)
try:
    # First, check if index already exists
    try:
        index = client.get_index(index_name=index_name, endpoint_name=endpoint_name, primary_key=primary_key, source_table_name=source_table)
        print(f"Index {index_name} already exists")
    except:
        index = client.create_delta_sync_index_and_wait(
            index_name=index_name,
            endpoint_name=endpoint_name,
            source_table_name=source_table,
            primary_key=primary_key,
            embedding_source_column=embedding_source_column,
            embedding_model_endpoint_name='databricks-gte-large-en',
            embedding_dimension=1024,
            pipeline_type="TRIGGERED"
        )
except Exception as e:
    print(e)

# COMMAND ----------

# MAGIC %md
# MAGIC Great! Now we have created our Delta sync index. 
# MAGIC
# MAGIC
# MAGIC ### Step 5: Test the index
# MAGIC Let's test whether it works by doing a similarity search. Do a similarity search on, for example, the word "grønland". Test the index with multiple searches and num_results. 

# COMMAND ----------

# TODO: Test index by performing a similarity search by changing query_text:
results = index.similarity_search(
    query_text="Vil jeg træde tilbage som Danmarks dronning",
    columns=["chunk_id", "chunk"],
    num_results=5
    )
display(results)

# COMMAND ----------

# MAGIC %md
# MAGIC ✅ Well done! 
# MAGIC
# MAGIC You've now built your own Delta Sync Vector Index that automatically generates and maintains embeddings of your document chunks and stays in sync with your data - and which enables you to perform semantic searches across your knowledgebase.
# MAGIC
# MAGIC Next, we'll use this to power our question-answering system with our documents as context!
# MAGIC