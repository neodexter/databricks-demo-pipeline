# For testing purposes
# !pip install backoff mlflow databricks_openai pydantic openai
# dbutils.library.restartPython()

import json
from typing import Any, Callable, Dict, Generator, List, Optional
from uuid import uuid4

import backoff
import mlflow 
import openai
from databricks.sdk import WorkspaceClient
from databricks_openai import VectorSearchRetrieverTool, UCFunctionToolkit
from unitycatalog.ai.core.base import get_uc_function_client
from mlflow.entities import SpanType
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from openai import OpenAI
from pydantic import BaseModel

#### NOTE: You do not have to run this script. We run it as part of the next notebook. Just fill out what is described in the steps. #####

# We have done most of the job defining the agent for you. You need to define which model you want to use, a system prompt and point the agent towards your index.
# However, feel free to look through the code and get an idea of how to build your future agents.

# Step 1. *ACTION REQUIRED*
# We need to define the endpoint of the model we want to use. 
# Some models are already available to you. See the models tab in the sidebar.
# There are several models out there, each excelling in different tasks. Can you find one that performs better witth agentic chats?

LLM_ENDPOINT_NAME = "databricks-claude-3-7-sonnet"

# Step 2. *ACTION REQUIRED*
# Define a system prompt. 
# A system prompt in the context of language models like ChatGPT is a special instruction 
# or message given at the start of a conversation to guide the model’s behavior, tone, or personality. 
# It sets the rules of engagement for how the model should respond throughout the interaction.
# Maybe the agent should be the queen herself? You can write the system prompt in any language you

SYSTEM_PROMPT = """You are a chatbot with understanding of Danish language, political situation and able to translate to English
"""

TOOL_INFOS = []

VECTOR_SEARCH_TOOLS = []

# Step 3. *ACTION REQUIRED*
# Append the VectorSearchRetrieverTool to the VECTOR_SEARCH_TOOLS list
# We need to add two arguments. There is one mandatory argument to pass and that's the index from which the tools should perform it's search.
# You can add several other optional arguments. Find more information in the documentation.
# Documentation for VectorSearchRetriverTool: https://docs.databricks.com/aws/en/generative-ai/agent-framework/unstructured-retrieval-tools

VECTOR_SEARCH_TOOLS.append(
    VectorSearchRetrieverTool(
        index_name="bootcamp_vectorstores_dev.royal_knowledgebase.bootcamp_index_bna",
        num_results=20
    )
)

# Step 4.
# To register the tool and let the agent use it, we need to add information about the tool to the TOOL_INFOS list.
# You're telling the agent:
# name: What the tool is called—this is how the agent refers to it in its reasoning process.
# spec: The OpenAPI-style specification or schema that describes what the tool does, its inputs/outputs, etc. This helps the LLM understand how to use it properly.
# exec_fn: The actual function to call when the tool is invoked—what the agent will execute.

class ToolInfo(BaseModel):
    name: str
    spec: dict
    exec_fn: Callable

for vs_tool in VECTOR_SEARCH_TOOLS:
    TOOL_INFOS.append(
        ToolInfo(
            name=vs_tool.tool["function"]["name"],
            spec=vs_tool.tool,
            exec_fn=vs_tool.execute,

        )
    )

# Step 5.
# Now we have everything we need. Let's define the agent!
# Our agent needs a variety of functions to properly query the our vector index and output the necessary messages.
class ToolCallingAgent(ChatAgent):
    
    """
    Class representing a tool-calling Agent
    """

    # We have defined the constructor for you.
    def __init__(self, llm_endpoint: str, tools: Dict[str, Dict[str, Any]]):
        """
        Initializes the ToolCallingAgent with tools.

        Args:
            tools (Dict[str, Dict[str, Any]]): A dictionary where each key is a tool name,
            and the value is a dictionary containing:
                - "spec" (dict): JSON description of the tool (matches OpenAI format)
                - "function" (Callable): Function that implements the tool logic
        """
        super().__init__()
        self.llm_endpoint = llm_endpoint # Store the LLM endpoint string for later use
        self.workspace_client = WorkspaceClient() # Initialize a client to interact with the workspace
        self.model_serving_client: OpenAI = (
            self.workspace_client.serving_endpoints.get_open_ai_client() # Get an OpenAI-compatible client from the workspace for serving model requests
        )
        self._tools_dict = {
            tool.name: tool for tool in tools
        }  # Store tools for later execution   

    # We have defined the function for extracting out tool specs.
    def get_tool_specs(self):
        """
        Returns tool specifications in the format OpenAI expects.
        """
        return [tool_info.spec for tool_info in self._tools_dict.values()]

    # We need our agent to be able to execute the tools. Here we have defined the function for extracting the tools. 
    @mlflow.trace(span_type=SpanType.TOOL)
    def execute_tool(self, tool_name: str, args: dict) -> Any:
        """
        Executes the specified tool with the given arguments.

        Args:
            tool_name (str): The name of the tool to execute.
            args (dict): Arguments for the tool.

        Returns:
            Any: The tool's output.
        """
        if tool_name not in self._tools_dict:
            raise ValueError(f"Unknown tool: {tool_name}")
        return self._tools_dict[tool_name].exec_fn(**args)

    # We need to prepare the messages so that it can be pushed to the LLM. Some fields are not interpretable by the LLM and therefore have to be filtered out.
    # You can look at the ChatAgentMessage in mlflow and see what fields are created: 
    # https://mlflow.org/docs/latest/api_reference/python_api/mlflow.types.html#mlflow.types.agent.ChatAgentMessage

    # We need:
    # - The entity's role
    # - The content of the message
    # - The entity's name
    # - The list of tools
    # - The tools corresponding ID

    def prepare_messages_for_llm(self, messages: list[ChatAgentMessage]) -> list[dict[str, Any]]:
        """Filter out ChatAgentMessage fields that are not compatible with LLM message formats"""
        compatible_keys = ["role", "content", "name", "tool_calls", "tool_call_id"]
        return [
            {k: v for k, v in m.model_dump_compat(exclude_none=True).items() if k in compatible_keys} for m in messages
        ]

    # We have defined the this function, predict_stream, which is responsible for generating a stream of chat response chunks. 
    # It acts as an intermediate step before the predict function (which aggregates these chunks into a full response).
    @mlflow.trace(span_type=SpanType.AGENT)
    def predict_stream(
        self,
        messages: List[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> Generator[ChatAgentChunk, None, None]:
        if len(messages) == 0:
            raise ValueError(
                "The list of `messages` passed to predict(...) must contain at least one message"
            )
        all_messages = [
            ChatAgentMessage(role="system", content=SYSTEM_PROMPT)
        ] + messages

        try:
            for message in self.call_and_run_tools(messages=all_messages):
                print(message)
                yield ChatAgentChunk(delta=message)
        except openai.BadRequestError as e:
            error_data = getattr(e, "response", {}).get("json", lambda: None)()
            if error_data and "external_model_message" in error_data:
                external_error = error_data["external_model_message"].get("error", {})
                if external_error.get("code") == "content_filter":
                    yield ChatAgentChunk(
                        messages=[
                            ChatAgentMessage(
                                role="assistant",
                                content="I'm sorry, I can't respond to that request.",
                                id=str(uuid4())
                            )
                        ]
                    )
            raise  # Re-raise if it's not a content filter error

    @mlflow.trace(span_type=SpanType.AGENT)
    def predict(
        self,
        messages: List[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> ChatAgentResponse:
        """
        Primary function that takes a user's request and generates a response.
        """
        response_messages = [  
            chunk.delta       
            for chunk in self.predict_stream(messages, context, custom_inputs)
        ]  
        return ChatAgentResponse(messages=response_messages)  #  
    
    # Now we need a function for initializing the chat completion. Add the model, the messages and the tool to the chat completion!
    @backoff.on_exception(backoff.expo, openai.RateLimitError)
    def chat_completion(self, messages: List[ChatAgentMessage]) -> ChatAgentResponse:
        return self.model_serving_client.chat.completions.create(
            model=self.llm_endpoint,
            messages=self.prepare_messages_for_llm(messages),
            tools=self.get_tool_specs(),
        )

    # Finally, we have defined a function for orchestrating an iterative conversation loop between the chat model (assistant) and external tools.
    @mlflow.trace(span_type=SpanType.AGENT)
    def call_and_run_tools(
        self, messages, max_iter=10
    ) -> Generator[ChatAgentMessage, None, None]:
        current_msg_history = messages.copy()
        for i in range(max_iter):
            with mlflow.start_span(span_type="AGENT", name=f"iteration_{i + 1}"):
                # Get an assistant response from the model, add it to the running history
                # and yield it to the caller
                # NOTE: we perform a simple non-streaming chat completions here
                # Use the streaming API if you'd like to additionally do token streaming
                # of agent output.
                response = self.chat_completion(messages=current_msg_history)
                llm_message = response.choices[0].message
                assistant_message = ChatAgentMessage(**llm_message.to_dict(), id=str(uuid4()))
                current_msg_history.append(assistant_message)
                yield assistant_message

                tool_calls = assistant_message.tool_calls
                if not tool_calls:
                    return  # Stop streaming if no tool calls are needed

                # Execute tool calls, add them to the running message history,
                # and yield their results as tool messages
                for tool_call in tool_calls:
                    function = tool_call.function
                    args = json.loads(function.arguments)
                    # Cast tool result to a string, since not all tools return as tring
                    result = str(self.execute_tool(tool_name=function.name, args=args))
                    tool_call_msg = ChatAgentMessage(
                        role="tool", name=function.name, tool_call_id=tool_call.id, content=result, id=str(uuid4())
                    )
                    current_msg_history.append(tool_call_msg)
                    yield tool_call_msg

        yield ChatAgentMessage(
           content=f"I'm sorry, I couldn't determine the answer after trying {max_iter} times.",
           role="assistant",
           id=str(uuid4())
        )

# Step 6.
# Finally, we log the model using MLflow.
mlflow.openai.autolog()
AGENT = ToolCallingAgent(llm_endpoint=LLM_ENDPOINT_NAME, tools=TOOL_INFOS)
mlflow.models.set_model(AGENT)
