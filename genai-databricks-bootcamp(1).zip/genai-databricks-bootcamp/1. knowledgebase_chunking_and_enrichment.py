# Databricks notebook source
# MAGIC %md
# MAGIC ## Lab 1: Preparing and Enriching Our Knowledge Database
# MAGIC
# MAGIC Recap: You'll create a Retrieval-Augmented Generation (RAG) powered chatbot with a royal flair — a digital chat version of Queen Margrethe II 👑
# MAGIC
# MAGIC This is the first step in our solution:
# MAGIC > This notebook prepares Queen Margrethe’s raw text data (new years speeches) for our agent  → Creating clean, chunked documents with metadata
# MAGIC
# MAGIC
# MAGIC ### What you'll learn in this notebook:
# MAGIC - How to use Databricks widgets to parameterize your notebook i.e. adding simple input fields
# MAGIC - How to break up the New Year's speeches into chunks to get them ready for RAG.
# MAGIC - (Optional) How to enrich your data using an LLM to find and highlight important names and topics (also called named entities) in the speeches. This can improve how well information is found later (retrieval).
# MAGIC
# MAGIC **Output of this lab:**
# MAGIC - Data prepation ✅  
# MAGIC - A chunked and enriched dataset, saved as a table — ready for embedding!
# MAGIC
# MAGIC --- 
# MAGIC
# MAGIC Let’s get started building your knowledge base!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 0: Activate your cluster
# MAGIC
# MAGIC First, you need to activate your cluster. 
# MAGIC
# MAGIC 1. Click 'Connect' in top right corner and click 'More'
# MAGIC     <img src="assets/cluster1.png" alt="cluster1.png" width="30%">
# MAGIC
# MAGIC
# MAGIC 2. Second, choose the "Lab-Cluster-XXXXXX" available for you and click 'Start and attach'.
# MAGIC
# MAGIC
# MAGIC     <img src="assets/cluster2.png" alt="cluster2.png" width="30%">
# MAGIC
# MAGIC
# MAGIC The cluster may take a few minutes to start, so feel free to begin reading through the tasks in this notebook while you wait. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Load libraries

# COMMAND ----------

!pip install databricks-feature-engineering
dbutils.library.restartPython()

# COMMAND ----------

import json
from dbruntime.databricks_repl_context import get_context
from databricks.feature_engineering import FeatureEngineeringClient
import pyspark.sql.functions as func
from pyspark.sql.types import ArrayType, StringType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Understanding Databricks Widgets
# MAGIC
# MAGIC Widgets are interactive parameters that allow you to pass values into your notebook. After creating the widgets, they will appear in the top of the notebook, just below the title. Here you can change names of the parameters easily:
# MAGIC
# MAGIC ![](./widget.png)
# MAGIC
# MAGIC Widgets are crucial for creating parameterized workflows. You can define them manually or through code:
# MAGIC - **In this lab:** We're manually creating widgets to learn how they work
# MAGIC - **In production:** These parameters would be configured through e.g. workflows (jobs)
# MAGIC
# MAGIC ### Task 1: Create empty widgets
# MAGIC Create a username and run the cell below to create the empty widgets, and see them appear in the top of the notebook.
# MAGIC

# COMMAND ----------

# First, you need to define a username. This will be added to the name of your output table so you can easily see which one is yours.
# TODO: Replace "Your-Username-Here" with your own:
username = "bna"

# Here we are manually creating widgets for our parameters,  you don't need to change anything here:
dbutils.widgets.text("input_table", "")
dbutils.widgets.text("output_table", f"bootcamp_vectorstores_dev.royal_knowledgebase.newyears_speeches_chunked_{username}") 
dbutils.widgets.text("model", "")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2: Define widget parameters manually
# MAGIC
# MAGIC You should now be able to see the empty widgets for `input_table` and `model`. Before we can process Queen Margrethe's New Year's speech transcrips, we need to define these parameters:
# MAGIC
# MAGIC - `input_table`: This is the data, which we will base our RAG model on.
# MAGIC - `model`: This defines which large language model will be used to process the speech and find important names and topics (called named entities).
# MAGIC
# MAGIC `output_table`: This is where the processed results will be stored. This has already been defined for you as you can see in the widget.
# MAGIC
# MAGIC
# MAGIC **Instructions to define input_table and model widgets:**
# MAGIC
# MAGIC 1. Go to the Catalog in the left menu and locate the table that contains Queen Margrethe's New Year's speeches, which is called "_newyears_speeches_". 
# MAGIC 2. When found, copy the table path and insert into the "input_table" widget at top of the notebook.
# MAGIC 3. Find an appropriate chat `model`, and add the name of it to "model" widget at the top of the notebook.
# MAGIC
# MAGIC
# MAGIC 💡 Tip: To find the input_data table, look for curated and the path follow: catalog.schema.object structure.
# MAGIC
# MAGIC 💡 Tip: To see which large language models are available, check the _Serving_ section the left menu. Choose a model that has Task=Chat.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3: Retrieve and print your defined widgets
# MAGIC
# MAGIC Run cell below and check the outputs to ensure you have defined your widgets correctly.

# COMMAND ----------

input_table = dbutils.widgets.get("input_table")
output_table = dbutils.widgets.get("output_table")
browser_hostname = spark.conf.get("spark.databricks.workspaceUrl").split(".")[0]
model = dbutils.widgets.get("model")
DATABRICKS_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
print(
    f'''
    Input table: {input_table}, 
    Output table: {output_table}, 
    Model: {model}
    ''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4: Load our input data
# MAGIC
# MAGIC Now we have defined all relevant parameters! 
# MAGIC
# MAGIC Lets load our input data and create a dataframe from the input_table by running the cell below:

# COMMAND ----------

# Create dataframe
df = spark.read.table(input_table)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ______________________________

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Chunking the Speech Text
# MAGIC Great, we have our raw New Years speeches data. 
# MAGIC
# MAGIC However, for effective RAG, we need to break down the long speeches into smaller, manageable chunks. This is crucial because:
# MAGIC 1. LLMs have input token limits
# MAGIC 2. Smaller chunks enable more precise retrieval
# MAGIC 3. It helps maintain context during retrieval
# MAGIC
# MAGIC We're using a simple paragraph-based chunking strategy that splits text at double newlines (`\\n\\n`). This works well for structured speeches where paragraphs form natural semantic units.
# MAGIC
# MAGIC 💡 Tip - See overview of different chunking strategies here: https://community.databricks.com/t5/technical-blog/the-ultimate-guide-to-chunking-strategies-for-rag-applications/ba-p/113089
# MAGIC
# MAGIC
# MAGIC Let's implement our chunking strategy by simply running the cell below:

# COMMAND ----------

# Define our chunking function as a UDF (User Defined Function)
parser_udf = func.udf(
        lambda x: x.split('\n\n'), returnType=ArrayType(StringType()), useArrow=True
    )

# Apply the chunking function to our content column
df_chunk = df.withColumn(
        "content_chunked", parser_udf("content")
    ) 

# Explode the array of chunks into individual rows, assigning IDs
df_chunk = df_chunk.select(
        "*", func.posexplode("content_chunked").alias("chunk_id", "chunk")
    ).drop("content","content_chunked")

# Create composite chunk IDs that include the year for traceability
df_chunk = df_chunk.withColumn('chunk_id', func.concat_ws('_', "year", "chunk_id"))

display(df_chunk)
print("Take a look at the data. Do the chunks look right to you?")


# COMMAND ----------

# MAGIC %md
# MAGIC ___________________________

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 6: Save dataframe
# MAGIC
# MAGIC Now our data is chunked and ready for embedding! 
# MAGIC
# MAGIC In the cell below, we’ll save the chunked data as a table in the catalog so it can be used in the next steps.
# MAGIC
# MAGIC 👉 **Optional**: Before embedding, you can choose to enrich the chunks with metadata — like named entities — using a LLM. This can enhance search and retrieval later in your RAG pipeline. If you’d like to explore that, you can return to Step 7 (Optional) after completing the main lab.

# COMMAND ----------

df_chunk.write.mode("overwrite").format("delta").option("delta.enableChangeDataFeed", "true").saveAsTable(output_table)

# COMMAND ----------

# MAGIC %md
# MAGIC _____________________

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 7 (Optional): Enriching Chunks with Named Entities
# MAGIC
# MAGIC Before embedding the speech chunks, we can optionally enrich them with metadata by extracting named entities — such as people, places, or organizations — using a LLM. This can improve search and retrieval performance in our RAG pipeline.
# MAGIC
# MAGIC ⚠️ **This step may take ~10 minutes** to run on the full dataset. We therefore recommend completing the core lab first and returning to this step later if you'd like to explore it further.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC 💡 **Entity extraction as a tool**  
# MAGIC In this step, we define the entity extraction as a *tool* the LLM can call. By defining a tool, it helps structure the LLM’s output in a clean, reusable way—and makes it easy to extend with more tools later if needed.
# MAGIC
# MAGIC Below you see the definition of the tool that extracts named entities from each chunk. Run the cell.
# MAGIC

# COMMAND ----------

# Define the tools for our LLM 
tools = [
   {
     "type": "function",
     "function": {
       "name": "named_entities",
       "description": "Extract named entities from text",
       "parameters": {
         "type": "object",
         "properties": {
           "entities": {
             "type": "array",
             "items": {
             "type": "string"
             },
             "description": "List of named entities found in the text"
           },
         }
       }
     }
   }
 ]

# COMMAND ----------

# MAGIC %md
# MAGIC ### (Optional) Task 7.1: Define the entity extraction
# MAGIC
# MAGIC Define the function tool for extracting entities using LLM. Entities will be added to our dataframe. 
# MAGIC
# MAGIC **You need to:**
# MAGIC - Write out a system prompt that tells the AI assistant to extract named entities from a text document. Tweak the prompt to see how output changes. 
# MAGIC
# MAGIC
# MAGIC 💡 Hint: Clearer instructions in the system message can make a big difference of the extracted named entities!
# MAGIC
# MAGIC
# MAGIC 💡 Hint: Read documentation about tool function calling here: https://platform.openai.com/docs/guides/function-calling?api-mode=chat 

# COMMAND ----------

## Define UDF for metada extraction
@func.udf(returnType=ArrayType(StringType()), useArrow=True)
def extract_entities(text: str) -> list[str]:
  from openai import OpenAI
  # Initialize OpenAI client with Databricks credentials
  client = OpenAI(
    api_key=DATABRICKS_TOKEN,
    base_url=f"https://{browser_hostname}.cloud.databricks.com/serving-endpoints",
    )
  
  # Send prompt to the model using a system prompt and the input text
  chat_completion = client.chat.completions.create(
    messages=[
    {
      "role": "system",
      "content": "You are an AI assistant that extract entities from a speech."
    },
    {
      "role": "user",
      "content": text
    }
    ],
    # Use your selected model for the task
    model=model,
    max_tokens=256,
    tools = tools
  )
  try:
    entities = json.loads((chat_completion.choices[0].message.tool_calls[0].function.arguments)).get('entities',[])
  except:
    entities = []
  return entities

# COMMAND ----------

# MAGIC %md
# MAGIC ### (Optional) Task 7.2: Test and run the entity extraction
# MAGIC
# MAGIC Lets run the entity extraction function and see the entities being added to our dataframe.
# MAGIC
# MAGIC 💡 Tip: Use `.limit(10)` to test on a few rows first.
# MAGIC

# COMMAND ----------

# Add metadata to dataframe 
df_chunk_ent = df_chunk.withColumn(
        "entities", extract_entities("chunk")
    ) 
display(df_chunk_ent)

# COMMAND ----------

# MAGIC %md
# MAGIC ### (Optional) Task 7.3: Save dataframe
# MAGIC
# MAGIC Now our data is chunked, enriched and ready for embedding! 
# MAGIC
# MAGIC In the cell below, we’ll save the chunked and enriched data as a table in the catalog so it can be used in the next steps.

# COMMAND ----------

# Write chunked data to a Delta table (takes approx. 6 minutes)
df_chunk_ent.write.mode("overwrite").format("delta").option("delta.enableChangeDataFeed", "true").saveAsTable(f'{output_table}_enriched')